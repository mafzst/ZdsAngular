﻿(function() {
	\* C'est ici que l'on va travailler */
})();
